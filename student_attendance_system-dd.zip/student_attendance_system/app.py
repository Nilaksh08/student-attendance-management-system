
from flask import Flask, render_template, request, redirect, url_for, flash
from database import get_connection, initialize_database

app = Flask(__name__)
app.secret_key = "student_management_secret_key"

initialize_database()


# HOME DASHBOARD
@app.route("/")

# PROFESSIONAL DASHBOARD

@app.route("/")
def home():

    conn = get_connection()

    # Total students
    total_students = conn.execute("""
        SELECT COUNT(*) FROM students
    """).fetchone()[0]

    # Total attendance records
    total_attendance = conn.execute("""
        SELECT COUNT(*) FROM attendance
    """).fetchone()[0]

    # Present students
    total_present = conn.execute("""
        SELECT COUNT(*) FROM attendance
        WHERE status = 'Present'
    """).fetchone()[0]

    # Absent students
    total_absent = conn.execute("""
        SELECT COUNT(*) FROM attendance
        WHERE status = 'Absent'
    """).fetchone()[0]

    # Total result records
    total_results = conn.execute("""
        SELECT COUNT(*) FROM results
    """).fetchone()[0]

    # Average marks
    average_marks = conn.execute("""
        SELECT AVG(marks) FROM results
    """).fetchone()[0]

    average_marks = round(average_marks, 2) if average_marks is not None else 0

    # Students grouped by course
    course_data = conn.execute("""
        SELECT course, COUNT(*) AS total
        FROM students
        GROUP BY course
        ORDER BY total DESC
    """).fetchall()

    course_labels = [row["course"] for row in course_data]
    course_values = [row["total"] for row in course_data]

    # Attendance statistics
    attendance_labels = ["Present", "Absent"]
    attendance_values = [total_present, total_absent]

    # Average marks by subject
    subject_data = conn.execute("""
        SELECT subject, ROUND(AVG(marks), 2) AS average
        FROM results
        GROUP BY subject
        ORDER BY subject
    """).fetchall()

    subject_labels = [row["subject"] for row in subject_data]
    subject_values = [row["average"] for row in subject_data]

    conn.close()

    return render_template(
        "index.html",
        total_students=total_students,
        total_attendance=total_attendance,
        total_present=total_present,
        total_absent=total_absent,
        total_results=total_results,
        average_marks=average_marks,
        course_labels=course_labels,
        course_values=course_values,
        attendance_labels=attendance_labels,
        attendance_values=attendance_values,
        subject_labels=subject_labels,
        subject_values=subject_values
    )


# ADD STUDENT
@app.route("/add_student", methods=["GET", "POST"])
def add_student():

    if request.method == "POST":

        name = request.form.get("name", "").strip()
        dob = request.form.get("dob", "")
        gender = request.form.get("gender", "")
        email = request.form.get("email", "").strip()
        phone = request.form.get("phone", "").strip()
        course = request.form.get("course", "").strip()
        address = request.form.get("address", "").strip()

        if not name or not course:
            flash("Name and course are required!", "error")
            return redirect(url_for("add_student"))

        conn = get_connection()

        try:
            conn.execute("""
                INSERT INTO students
                (name, dob, gender, email, phone, course, address)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (name, dob, gender, email or None,
                  phone, course, address))

            conn.commit()
            flash("Student added successfully!", "success")

        except Exception as e:
            flash(f"Error: {e}", "error")

        finally:
            conn.close()

        return redirect(url_for("view_students"))

    return render_template("add_student.html")


# VIEW AND SEARCH STUDENTS
@app.route("/students")
def view_students():

    search = request.args.get("search", "").strip()

    conn = get_connection()

    students = conn.execute("""
        SELECT * FROM students
        WHERE name LIKE ? OR course LIKE ?
        ORDER BY id DESC
    """, (f"%{search}%", f"%{search}%")).fetchall()

    conn.close()

    return render_template(
        "view_students.html",
        students=students,
        search=search
    )


# EDIT STUDENT
@app.route("/edit_student/<int:id>", methods=["GET", "POST"])
def edit_student(id):

    conn = get_connection()

    student = conn.execute(
        "SELECT * FROM students WHERE id = ?", (id,)
    ).fetchone()

    if student is None:
        conn.close()
        flash("Student not found!", "error")
        return redirect(url_for("view_students"))

    if request.method == "POST":

        name = request.form.get("name", "").strip()
        dob = request.form.get("dob", "")
        gender = request.form.get("gender", "")
        email = request.form.get("email", "").strip()
        phone = request.form.get("phone", "").strip()
        course = request.form.get("course", "").strip()
        address = request.form.get("address", "").strip()

        if not name or not course:
            conn.close()
            flash("Name and course are required!", "error")
            return redirect(url_for("edit_student", id=id))

        try:
            conn.execute("""
                UPDATE students
                SET name=?, dob=?, gender=?, email=?,
                    phone=?, course=?, address=?
                WHERE id=?
            """, (name, dob, gender, email or None,
                  phone, course, address, id))

            conn.commit()
            flash("Student updated successfully!", "success")

        except Exception as e:
            flash(f"Error: {e}", "error")

        finally:
            conn.close()

        return redirect(url_for("view_students"))

    conn.close()

    return render_template("edit_student.html", student=student)


# DELETE STUDENT
@app.route("/delete_student/<int:id>", methods=["POST"])
def delete_student(id):

    conn = get_connection()

    conn.execute(
        "DELETE FROM students WHERE id = ?", (id,)
    )

    conn.commit()
    conn.close()

    flash("Student deleted successfully!", "success")

    return redirect(url_for("view_students"))


# ATTENDANCE MANAGEMENT

from datetime import date


@app.route("/attendance", methods=["GET", "POST"])
def attendance():

    conn = get_connection()

    # Mark attendance
    if request.method == "POST":

        student_id = request.form.get("student_id")
        attendance_date = request.form.get("date")
        status = request.form.get("status")

        if not student_id or not attendance_date or status not in ["Present", "Absent"]:
            conn.close()
            flash("Please fill all attendance details correctly!", "error")
            return redirect(url_for("attendance"))

        student = conn.execute(
            "SELECT id FROM students WHERE id = ?",
            (student_id,)
        ).fetchone()

        if student is None:
            conn.close()
            flash("Please select a valid student!", "error")
            return redirect(url_for("attendance"))

        # Check if attendance already exists
        existing = conn.execute("""
            SELECT id FROM attendance
            WHERE student_id = ? AND date = ?
        """, (student_id, attendance_date)).fetchone()

        try:
            if existing:
                # Update existing attendance
                conn.execute("""
                    UPDATE attendance
                    SET status = ?
                    WHERE id = ?
                """, (status, existing["id"]))

                flash("Attendance updated successfully!", "success")

            else:
                # Insert new attendance
                conn.execute("""
                    INSERT INTO attendance
                    (student_id, date, status)
                    VALUES (?, ?, ?)
                """, (student_id, attendance_date, status))

                flash("Attendance marked successfully!", "success")

            conn.commit()

        except Exception as e:
            flash(f"Error: {e}", "error")

        finally:
            conn.close()

        return redirect(url_for("attendance"))

    # Get registered students
    students = conn.execute("""
        SELECT id, name FROM students
        ORDER BY name
    """).fetchall()

    # Get attendance records
    records = conn.execute("""
        SELECT attendance.id,
               students.name,
               attendance.date,
               attendance.status
        FROM attendance
        JOIN students
        ON attendance.student_id = students.id
        ORDER BY attendance.date DESC, attendance.id DESC
    """).fetchall()

    # Attendance statistics
    total_present = conn.execute("""
        SELECT COUNT(*) FROM attendance
        WHERE status = 'Present'
    """).fetchone()[0]

    total_absent = conn.execute("""
        SELECT COUNT(*) FROM attendance
        WHERE status = 'Absent'
    """).fetchone()[0]

    conn.close()

    return render_template(
        "attendance.html",
        students=students,
        records=records,
        total_present=total_present,
        total_absent=total_absent,
        today=date.today().isoformat()
    )


# DELETE ATTENDANCE RECORD
@app.route("/delete_attendance/<int:id>", methods=["POST"])
def delete_attendance(id):

    conn = get_connection()

    conn.execute(
        "DELETE FROM attendance WHERE id = ?", (id,)
    )

    conn.commit()
    conn.close()

    flash("Attendance record deleted successfully!", "success")

    return redirect(url_for("attendance"))


# MARKS AND RESULTS MANAGEMENT

def calculate_grade(percentage):
    if percentage >= 90:
        return "A+"
    elif percentage >= 80:
        return "A"
    elif percentage >= 70:
        return "B"
    elif percentage >= 60:
        return "C"
    elif percentage >= 50:
        return "D"
    else:
        return "F"


# ADD AND VIEW RESULTS
@app.route("/results", methods=["GET", "POST"])
def results():

    conn = get_connection()

    if request.method == "POST":

        student_id = request.form.get("student_id")
        subject = request.form.get("subject", "").strip()
        marks_input = request.form.get("marks", "").strip()

        if not student_id or not subject or not marks_input:
            conn.close()
            flash("Please fill all fields!", "error")
            return redirect(url_for("results"))

        try:
            marks = float(marks_input)

            if marks < 0 or marks > 100:
                raise ValueError("Marks must be between 0 and 100.")

            student = conn.execute(
                "SELECT id FROM students WHERE id = ?",
                (student_id,)
            ).fetchone()

            if student is None:
                raise ValueError("Please select a valid student.")

            # Check whether this subject already has marks
            existing = conn.execute("""
                SELECT id FROM results
                WHERE student_id = ? AND LOWER(subject) = LOWER(?)
            """, (student_id, subject)).fetchone()

            if existing:
                conn.execute("""
                    UPDATE results
                    SET marks = ?
                    WHERE id = ?
                """, (marks, existing["id"]))

                flash("Existing subject marks updated!", "success")

            else:
                conn.execute("""
                    INSERT INTO results (student_id, subject, marks)
                    VALUES (?, ?, ?)
                """, (student_id, subject, marks))

                flash("Student result added successfully!", "success")

            conn.commit()

        except ValueError as e:
            flash(str(e), "error")

        except Exception as e:
            flash(f"Error: {e}", "error")

        finally:
            conn.close()

        return redirect(url_for("results"))

    # Get all students
    students = conn.execute("""
        SELECT id, name FROM students
        ORDER BY name
    """).fetchall()

    # Get subject-wise results
    records = conn.execute("""
        SELECT results.id,
               students.name,
               students.id AS student_id,
               results.subject,
               results.marks
        FROM results
        JOIN students
        ON results.student_id = students.id
        ORDER BY students.name, results.subject
    """).fetchall()

    # Calculate total marks and percentage for each student
    summaries = conn.execute("""
        SELECT students.id AS student_id,
               students.name,
               COUNT(results.id) AS total_subjects,
               SUM(results.marks) AS total_marks,
               AVG(results.marks) AS percentage
        FROM students
        JOIN results ON students.id = results.student_id
        GROUP BY students.id, students.name
        ORDER BY students.name
    """).fetchall()

    # Calculate grade for each student's average
    summaries = [
        {
            "student_id": row["student_id"],
            "name": row["name"],
            "total_subjects": row["total_subjects"],
            "total_marks": row["total_marks"],
            "percentage": row["percentage"],
            "grade": calculate_grade(row["percentage"])
        }
        for row in summaries
    ]

    conn.close()

    return render_template(
        "results.html",
        students=students,
        records=records,
        summaries=summaries
    )


# EDIT RESULT
@app.route("/edit_result/<int:id>", methods=["GET", "POST"])
def edit_result(id):

    conn = get_connection()

    result = conn.execute("""
        SELECT * FROM results WHERE id = ?
    """, (id,)).fetchone()

    if result is None:
        conn.close()
        flash("Result not found!", "error")
        return redirect(url_for("results"))

    if request.method == "POST":

        subject = request.form.get("subject", "").strip()
        marks_input = request.form.get("marks", "").strip()

        try:
            marks = float(marks_input)

            if not subject:
                raise ValueError("Subject name is required.")

            if marks < 0 or marks > 100:
                raise ValueError("Marks must be between 0 and 100.")

            duplicate = conn.execute("""
                SELECT id FROM results
                WHERE student_id = ?
                AND LOWER(subject) = LOWER(?)
                AND id != ?
            """, (result["student_id"], subject, id)).fetchone()

            if duplicate:
                raise ValueError("This student already has marks for this subject.")

            conn.execute("""
                UPDATE results
                SET subject = ?, marks = ?
                WHERE id = ?
            """, (subject, marks, id))

            conn.commit()
            flash("Result updated successfully!", "success")

        except ValueError as e:
            flash(str(e), "error")

        except Exception as e:
            flash(f"Error: {e}", "error")

        finally:
            conn.close()

        return redirect(url_for("results"))

    conn.close()

    return render_template("edit_result.html", result=result)


# DELETE RESULT
@app.route("/delete_result/<int:id>", methods=["POST"])
def delete_result(id):

    conn = get_connection()

    conn.execute(
        "DELETE FROM results WHERE id = ?", (id,)
    )

    conn.commit()
    conn.close()

    flash("Result deleted successfully!", "success")

    return redirect(url_for("results"))


if __name__ == "__main__":
    app.run(debug=True)
